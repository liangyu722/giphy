package com.android.giphy.common

class RepositoryLoadingException(message: String) : RuntimeException(message)
